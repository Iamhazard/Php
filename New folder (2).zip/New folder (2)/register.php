<?php
    require_once "config.php";
    $username = $email = $password = $cpassword = $phonenumber="";
    $username_err = $email_err= $password_err = $cpassword_err = $phonenumber_err="";

    if($_SERVER['REQUEST_METHOD'] == "POST"){
        if(empty(trim($_POST["username"]))){
            $username_err = "Username cannot be blank";
        }
        else{
            $sql = "Select id from users Where username = ?";
            $stmt = mysqli_prepare($conn,$sql);
            if($stmt)
            {
                mysqli_stmt_bind_param($stmt,"s",$param_username);
                $param_username = trim($_POST['username']);

                if(mysqli_stmt_execute($stmt)){
                    mysqli_stmt_store_result($stmt);
                    if(mysqli_stmt_num_rows($stmt)==1){
                        $username_err = "This username is already taken";
                    }
                    else{
                        $username = trim($_POST['username']);
                    }
                }
                else{
                    echo "Something went wrong";
                }
            }
        }
        mysqli_stmt_close($stmt);

    if(empty(trim($_POST['email']))){
            $email_err = "Email cannot be blank";
    }
    else{
            $email = trim($_POST['email']);
    }
    if(empty(trim($_POST['phonenumber']))){
        $phonenumber_err = "Phone Number cannot be blank";
        }
    else{
        $phonenumber = trim($_POST['phonenumber']);
    }

    if(empty(trim($_POST['password']))){
        $password_err = "Pasword cannot be blank";
    }
    elseif(strlen(trim($_POST['password'])) < 5){
        $password_err = "Password cannot be less than 5 characters";
    }
    else{
        $password = trim($_POST['password']);
    }

    if(trim($_POST['password']) != trim($_POST['cpassword'])){
        $password_err = "Pasword should match";
    }

    if(empty($username_err) && empty($password_err) && empty($cpassword_err)&& empty($phonenumber_err)){
        $sql = "Insert into users (username,password,email,phonenumber) values(?,?,?,?)";
        $stmt  = mysqli_prepare ($conn,$sql);
        if($stmt){
            mysqli_stmt_bind_param($stmt,"ssss",$param_username,$param_password,$param_email,$param_phonenumber);

            $param_username = $username;
            $param_email = $email;
            $param_password = $password;
            $param_phonenumber = $phonenumber;

            if(mysqli_stmt_execute($stmt)){
                header('Location: signin.php');
                die;

            }
            else{
                echo "Something went wrong !";
            }
        }
        mysqli_stmt_close($stmt);
    }65
    mysqli_stmt_close($conn);
}

?>