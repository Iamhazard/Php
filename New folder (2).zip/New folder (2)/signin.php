
<?php
    
    require_once "config.php";
    
    $username = $password = "";
    $err = "";
    if ($_SERVER['REQUEST_METHOD'] == "POST"){
        if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
        {
            $err = "Please enter username and password";
        }
        else{
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);
        }
        if(empty($err))
        {
        
            $sql=  "select id,username,password from users where username = ?";
            $stmt = mysqli_prepare($conn,$sql);
            mysqli_stmt_bind_param($stmt,"s",$param_username);
            $param_username = $username;
    
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
    
    
                if(mysqli_stmt_num_rows($stmt) == 1){
    
                    mysqli_stmt_bind_result($stmt,$id,$username,$dpassword);
                    
                    if(mysqli_stmt_fetch($stmt)){
                        if($password == $dpassword)
                        {
                            session_start();
                            $_SESSION['username'] = $username;
                            $_SESSION['id']=$id;
                            $_SESSION['loggedin']=true;
    
                            header("location: welcome.php");
                        }
                        else{
                            echo'<p align = "center"> Oh sorry username and password not match';
                            
                        }
                    }
                    
                }
                else{
                echo'<p align = "center"> Oh sorry username and password not match';
    
            }
    
        }
        
    }
    }
    ?>  
<!DOCTYPE html>
<!-- === Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- ===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="style.css">
         
    <title>Login & Registration Form</title>
</head>
<body>
    
    <div class="container">
        <div class="forms">
            <!-- Login -->
            <div class="form login">
                <span class="title">Login</span>

                <form action="" method="post">
                    <div class="input-field">
                        <input type="text" name="username" placeholder="Enter your username" required>
                        <i class="uil uil-user"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" name="password" class="password" placeholder="Enter your password" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div class="checkbox-text">
                        <div class="checkbox-content">
                            <input type="checkbox" id="logCheck">
                            <label for="logCheck" class="text">Remember me</label>
                        </div>
                        
                        <a href="#" class="text">Forgot password?</a>
                    </div>

                    <div class="input-field button">
                        <input type="submit" value="Login Now">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Not a member?
                        <a href="#" class="text signup-link">Signup now</a>
                    </span>
                </div>
            </div>

            <!-- Registration Form -->
            <div class="form signup">
                <span class="title">Registration</span>

                <form action="register.php" method="Post" class="login-email">
                    <div class="input-field">
                        <input type="text" placeholder="Enter your name" name="username" required>
                        <i class="uil uil-user"></i>
                    </div>
                    <div class="input-field">
                        <input type="text" placeholder="Enter your email" name="email" required>
                        <i class="uil uil-envelope icon"></i>
                    </div> 
                    <div class="input-field">
                        <input type="tel"  placeholder="Enter Your Phone Number" name="phonenumber" required>
                        <i class="uil uil-phone"></i>
                    </div>
                    
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Create a password" name="password" required>
                        <i class="uil uil-lock icon"></i>
                    </div>
                    <div class="input-field">
                        <input type="password" class="password" placeholder="Confirm a password" name="cpassword" required>
                        <i class="uil uil-lock icon"></i>
                        <i class="uil uil-eye-slash showHidePw"></i>
                    </div>

                    <div name="submit" class="input-field button">
                        <input type="submit" name="submit" value="Sign Up">
                    </div>
                </form>

                <div class="login-signup">
                    <span class="text">Already got an account?
                        <a href="#" class="text login-link">Login here</a>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <script>
        const container = document.querySelector(".container"),
      pwShowHide = document.querySelectorAll(".showHidePw"),
      pwFields = document.querySelectorAll(".password"),
      signUp = document.querySelector(".signup-link"),
      login = document.querySelector(".login-link");

    //   js code to show/hide password and change icon
    pwShowHide.forEach(eyeIcon =>{
        eyeIcon.addEventListener("click", ()=>{
            pwFields.forEach(pwField =>{
                if(pwField.type ==="password"){
                    pwField.type = "text";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye-slash", "uil-eye");
                    })
                }else{
                    pwField.type = "password";

                    pwShowHide.forEach(icon =>{
                        icon.classList.replace("uil-eye", "uil-eye-slash");
                    })
                }
            }) 
        })
    })


    // js code to appear signup and login form
    signUp.addEventListener("click", ( )=>{
        container.classList.add("active");
    });
    login.addEventListener("click", ( )=>{
        container.classList.remove("active");
    });

    </script>
</body> 
</html>

