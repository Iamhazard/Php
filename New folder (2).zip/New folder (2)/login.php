<?php
    
require_once "config.php";

$username = $password = "";
$err = "";
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter username and password";
    }
    else{
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
    }
    if(empty($err))
    {
    
        $sql=  "select id,username,password from users where username = ?";
        $stmt = mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,"s",$param_username);
        $param_username = $username;

        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);


            if(mysqli_stmt_num_rows($stmt) == 1){

                mysqli_stmt_bind_result($stmt,$id,$username,$dpassword);
                
                if(mysqli_stmt_fetch($stmt)){
                    if($password == $dpassword)
                    {
                        session_start();
                        $_SESSION['username'] = $username;
                        $_SESSION['id']=$id;
                        $_SESSION['loggedin']=true;

                        header("location: welcome.php");
                    }
                    else{
                        echo'<p align = "center"> Oh sorry username and password not match';
                        
                    }
                }
                
            }
            else{
            echo'<p align = "center"> Oh sorry username and password not match';

        }

    }
    
}
}
?>  