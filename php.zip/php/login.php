<?php
session_start();
$uname="";
$pwd="";
if (isset($_POST["btnOk"]))
{
    $uname=$_POST["txtusername"];
    $pwd=$_POST["txtpassword"];
    if($uname=="admin" && $pwd=="admin")
    {
        $_SESSION["valid"]="ok";
        header("location:ab.php");
   }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login page</title>
</head>
<body>
    <style>
        body {
    background-color:#8f966b;}

   h1
      {color: rebeccapurple;}

   

    </style>
    <form action="login.php" method="post">
        <h1>Login </h1>
        user id: <input type="text" name="txtusername" value="<?php echo $uname;?>"><br>
        Password: <input type="tex" name="txtpassword" value="<?php echo $pwd;?>"><br>
        <input type="submit" value="Ok" name="btnOk">
    </form>
    
</body>
</html>