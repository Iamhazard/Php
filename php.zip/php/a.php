<?php
    
 $v1="";
$v2="";
$r="";
if (isset($_GET["btnadd"]))
    
{
    $v1=$_GET["txtv1"];
    $v2=$_GET["txtv2"];
    $r=$v1+$v2;
}   
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=<device-width>, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
<form action="a.php" method="get">
    
   value1<input type="text" name="txtv1" value="<?php echo $v1;?>"><br>
    Value2 <input type="text" name="txtv2" value="<?php echo $v2;?>"><br>
    <input type="submit" name="btnadd" value="Add">

    Result<input type="text" name="txtresult" value="<?php echo $r?>"><br>
    </form>
</body>
</html>