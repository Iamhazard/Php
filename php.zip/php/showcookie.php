<?php
$name="";
if(isset($_COOKIE["name"]))
{
$name=$_COOKIE["name"];
}
else
{
$name="Guest";
}

?>

<html>
<head>
<title>Read Cookie </title>
</head>
<body>
<form action="showcookie.php" action="get">
Your name form Cookie is <?php echo $name ;?>
</form>

</body>
</html>