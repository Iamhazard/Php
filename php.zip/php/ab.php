<?php
session_start();
if(isset($_SESSION["valid"]))
{

}
else
{
    header("location:login.php");
}
if(isset($_POST["btnlogout"]))
{
    session_destroy();
    header("location:login.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login1.css">
    <title>login page</title>
   
    
</head>

<body>
    
    <form action="ab.php" method="Post">
        <h1> Welcome to chitwan</h1>
        <div>
        <input type="submit"  name="btnlogout" value="Logout">

        </div>
    </form>
    
</body>
</html>