<?php
$n1="";
$n2="";
$r="";
if(isset($_GET["btnCheck"]))
{
$n1=$_GET["txtNumber1"];
$n2=$_GET["txtNumber2"];

$r=pow($n1,$n2);

}

?>



<html>
<head>
<title>Square of number</title>
</head>
<body>
<form action="Square.php" method="get">
Enter a Number<input type="text" name="txtNumber1" value="<?php echo $n1; ?>"><br>
Enter square value<input type="text" name="txtNumber2" value="<?php echo $n2; ?>"><br>


<input type="submit" value="Check" name="btnCheck"><br><br>
Result:<input type="text" name="txtCheck" value="<?php echo $r; ?>"><br>
</form>
</body>
</html>