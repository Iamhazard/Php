<?php
$v1="";
$v2="";
$t="";
$r="";
if(isset($_POST["btncalculate"]))
{
    $v1=$_POST["txtv1"];
    $v2=$_POST["txtv2"];
    $t=$_POST["txtv3"];

    $r=($v1*$v2*$t)/100;
    $C=($)
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple intrest</title>
</head>
<body>
    <form action="simpl.php" method="post">
    Principal Amount<input type="text" name="txtv1" value="<?php echo $v1;?>"><br>
    Rate% <input type="text" name="txtv2" value="<?php echo $v2;?>"><br>
    time:<input type="text" name="txtv3" value="<?php echo $t;?>"> <br>

    <input type="submit" name="btncalculate" value="Calculate"><br>

Simple intrest:<input type="text" name="txtresult" value="<?php echo $r;?>"><br>
compound intrest <input type="text" name=""
    </form>
    
</body>
</html>