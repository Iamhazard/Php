<?php
$n="";
$o="";
if(isset($_GET["btnClick"]))
{
$n=$_GET["txtNumber"];
 $i;
// while($i<=$n)
for($i=1;$i<=$n;$i++)
{
    // $i++;
    echo  $i;
    echo "<br>";
}

}

?>



<html>
<head>
<title>Display Numbers</title>
</head>
<body>
<form action="display_numbers.php" method="get">
Enter the number how many terms you want to display<input type="text" name="txtNumber" value="<?php echo $n; ?>"><br>


<input type="submit" value="Click" name="btnClick"><br><br>
<!-- Output :<input type="text" name="txtClick" value="<?php echo $o; ?>"><br> -->
</form>
</body>
</html>