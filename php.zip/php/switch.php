<?php
$n="";
$d="";
if(isset($_GET["btnShow"]))
{
$n=$_GET["txtDayNumber"];
switch($n)
{
case 1:
$d="Sunday";
break;
case 2:
$d="Monday";
break;
case 3:
$d="Tuesday";
break;
case 4:
$d="Wednesday";
break;
case 5:
$d="Thursday";
break;
case 6:
$d="Friday";
break;
case 7:
$d="Saturday";
break;
default:
$d="Invalid";
}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

     body{
        background-color: blueviolet;
        font-family: "Courier New", Courier, monospace;
        position: relative;
        color: red;
        border: 5px solid red;


     }
     group{
         display: flexbox;
         width: 50vw;
     }
    </style>
    <title>switch illustration</title>

</head>


<body>
    <div class="group">
   <form action="switch.php" method="get">
            Enter Day Number<input type="text" name="txtDayNumber" value="<?php echo $n; ?>"><br>
            
            <input type="submit" value="Show" name="btnShow">
            Week Day Name <input type="text" name="txtWeekDay" value="<?php echo $d; ?>"><br>
            </form>
    </div>
 

    
</body>
</html>