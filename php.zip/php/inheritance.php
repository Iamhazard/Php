<?php
class employee{
   public $name;
   public $address;
    public function __construct($name,$address){
        $this->name ="";
        $this ->address ="";
    
    }
    public function setName($name){
        $this->name=$name;
       }
       public function setAddress($address)
       {
           $this->address=$address;
       }
}

class permanent {
  public  $salary;
   public $post;

 function __construct($name,$address,$salary,$post)
{
  parent::__construct($name,$address);
  $this ->salary=$salary;
  $this -> post=$post;

}
 function setSalary($salary)
{
    $this ->salary =$salary;

}
function setPost($post){
    $this -> post =$post;
}
function displayAll()
{
    echo $this-> name;
    echo $this-> address;
    echo $this-> salary;
    echo $this-> post;
}
}
$p1=new permanent("aayush","ctwn",5000,gatepale);
















?>


?>

