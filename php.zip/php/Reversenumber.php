<?php
$n="";
$s="";
if(isset($_GET["btnReverse"]))
{
    $n=$_GET["txtNumber"];
    $r=0;
  while($n>0)
  {
$s=$n%10;

$n=$n/10;

echo $s;
echo "<br>";

 }
  $s=$r;

  
   
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reverse number</title>
</head>
<body>
    <form action="Reversenumber.php">
    Enter Number:<input type="text" name="txtNumber" value="<?php echo $n;?>"><br>
    <input type="submit" name="btnReverse" value="Reverse"><br>
    Reversed Number:<name="txtReverse" value="<?php echo $s;?>"><br>
    </form>
    
</body>
</html>