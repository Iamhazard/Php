<?php
$n=$s="";
if(isset($_GET["btnsumdigit"]))
{
    $n=$x=$_GET["txtnumber"];
    $sum=0;
    $r;
    while($x>0)
    {
        $r=$x%10;
        $sum=$sum+$r;
        $x=floor($x/10);  
    }
    $s=$sum;

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sum of Digits</title>

</head>
<body>
        <form action="Sumdigit.php" method="get">
    Enter a number <input type="text" name="txtnumber" value="<?php echo $n;?>"> <br>
    <input type="submit" value="Sum digit" name="btnsumdigit">
    Sum of Digit<input type="text" name="txtsum" value="<?Php echo $s;?>"><br>

        </form>
    
    
</body>
</html>